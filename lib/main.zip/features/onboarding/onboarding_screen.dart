import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../home/main_shell.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  // 주파수 매처 상태
  double _selectedFreq = 8000;
  AudioPlayer? _tonePlayer;
  bool _toneIsPlaying = false;
  bool _freqSelected = false;

  @override
  void dispose() {
    _tonePlayer?.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _playTone(double freq) async {
    setState(() => _toneIsPlaying = true);
    try {
      await _tonePlayer?.stop();
      _tonePlayer?.dispose();
      _tonePlayer = AudioPlayer();
      final bytes = _buildSineWav(freq, 3);
      await _tonePlayer!.setAudioSource(_BytesSource(bytes));
      await _tonePlayer!.setVolume(0.35);
      await _tonePlayer!.play();
      await Future.delayed(const Duration(seconds: 3));
    } catch (e) {
      debugPrint('톤 오류: $e');
    } finally {
      if (mounted) setState(() => _toneIsPlaying = false);
    }
  }

  Future<void> _stopTone() async {
    await _tonePlayer?.stop();
    if (mounted) setState(() => _toneIsPlaying = false);
  }

  List<int> _buildSineWav(double freq, int secs) {
    const sr = 44100;
    final n = sr * secs;
    final fade = sr ~/ 4;
    final pcm = <int>[];
    for (int i = 0; i < n; i++) {
      double s = sin(2 * pi * freq * i / sr);
      if (i < fade) s *= i / fade;
      if (i > n - fade) s *= (n - i) / fade;
      final v = (s * 18000).round().clamp(-32768, 32767);
      pcm.add(v & 0xFF);
      pcm.add((v >> 8) & 0xFF);
    }
    List<int> intToBytes(int val, int cnt) =>
      List.generate(cnt, (i) => (val >> (8*i)) & 0xFF);
    final ds = pcm.length;
    return [
      0x52,0x49,0x46,0x46,...intToBytes(36+ds,4),
      0x57,0x41,0x56,0x45,0x66,0x6D,0x74,0x20,...intToBytes(16,4),
      ...intToBytes(1,2),...intToBytes(1,2),...intToBytes(sr,4),
      ...intToBytes(sr*2,4),...intToBytes(2,2),...intToBytes(16,2),
      0x64,0x61,0x74,0x61,...intToBytes(ds,4),...pcm,
    ];
  }

  Future<void> _finish() async {
    await _stopTone();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.keyOnboardingDone, true);
    await prefs.setDouble(AppConstants.keyTinnitusFreq, _selectedFreq);
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const MainShell()));
    }
  }

  void _next() {
    if (_currentPage < 3) {
      _stopTone();
      _pageController.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut);
    } else {
      _finish();
    }
  }

  String _freqLabel(double f) =>
    f >= 1000 ? '${(f/1000).toStringAsFixed(f%1000==0?0:1)}kHz' : '${f.round()}Hz';

  String _freqDesc(double f) {
    if (f < 2000) return '낮은 웅— 소리';
    if (f < 4000) return '중저음 이명';
    if (f < 6000) return '중고음 이명';
    if (f < 8000) return '고음 삐— 소리';
    if (f < 10000) return '높은 삐— 소리 (가장 흔한 유형)';
    return '매우 높은 고음';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.greenDark,
      body: SafeArea(
        child: Column(children: [
          // 상단 진행 표시
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
            child: Row(children: List.generate(4, (i) => Expanded(
              child: Container(
                height: 3,
                margin: EdgeInsets.only(right: i < 3 ? 6 : 0),
                decoration: BoxDecoration(
                  color: i <= _currentPage
                    ? AppColors.gold : Colors.white24,
                  borderRadius: BorderRadius.circular(2)),
              ),
            ))),
          ),

          Expanded(
            child: PageView(
              controller: _pageController,
              physics: const NeverScrollableScrollPhysics(),
              onPageChanged: (i) => setState(() => _currentPage = i),
              children: [
                _buildPage0(),
                _buildPage1(),
                _buildPage2(),
                _buildPage3(),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  // 페이지 0: 환영
  Widget _buildPage0() => Padding(
    padding: const EdgeInsets.all(32),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('👂', style: TextStyle(fontSize: 72)),
      const SizedBox(height: 24),
      const Text('Auris', style: TextStyle(
        color: Colors.white, fontSize: 48, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      const Text('이명과 함께 살아가는 것을\n조금 더 편안하게',
        textAlign: TextAlign.center,
        style: TextStyle(color: AppColors.greenLight, fontSize: 18, height: 1.5)),
      const SizedBox(height: 48),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16)),
        child: Column(children: [
          _InfoRow(icon: '🧠', text: '뉴캐슬대학 2025 논문 기반 신경 디싱크'),
          const SizedBox(height: 12),
          _InfoRow(icon: '📅', text: '하루 1시간 · 6주 프로그램'),
          const SizedBox(height: 12),
          _InfoRow(icon: '😴', text: '수면을 돕는 사운드 믹서'),
          const SizedBox(height: 12),
          _InfoRow(icon: '📊', text: '이명 패턴 기록 및 분석'),
        ]),
      ),
      const SizedBox(height: 48),
      _NextBtn(label: '시작하기', onTap: _next),
      const SizedBox(height: 16),
      const Text('⚠️ 이 앱은 의료기기가 아닙니다',
        style: TextStyle(color: AppColors.textLight, fontSize: 11)),
    ]),
  );

  // 페이지 1: 내 이명 주파수 찾기
  Widget _buildPage1() => Padding(
    padding: const EdgeInsets.fromLTRB(24, 24, 24, 32),
    child: Column(children: [
      const Text('내 이명 주파수 찾기',
        style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      const Text('가장 중요한 첫 번째 단계입니다\n내 이명 소리와 가장 비슷한 음을 찾으세요',
        textAlign: TextAlign.center,
        style: TextStyle(color: AppColors.greenLight, fontSize: 14, height: 1.5)),
      const SizedBox(height: 32),

      // 주파수 큰 표시
      Text(_freqLabel(_selectedFreq), style: const TextStyle(
        color: Colors.white, fontSize: 64, fontWeight: FontWeight.w200)),
      const SizedBox(height: 4),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.green.withOpacity(0.3),
          borderRadius: BorderRadius.circular(20)),
        child: Text(_freqDesc(_selectedFreq),
          style: const TextStyle(color: AppColors.greenLight, fontSize: 13)),
      ),
      const SizedBox(height: 24),

      // 슬라이더
      SliderTheme(
        data: SliderTheme.of(context).copyWith(
          activeTrackColor: AppColors.green,
          inactiveTrackColor: Colors.white24,
          thumbColor: AppColors.green,
          trackHeight: 4,
          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 14),
        ),
        child: Slider(
          value: _selectedFreq,
          min: 1000, max: 12000, divisions: 44,
          onChanged: (v) {
            final snapped = (v / 250).round() * 250.0;
            setState(() { _selectedFreq = snapped; _freqSelected = true; });
            _stopTone();
          },
        ),
      ),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: const [
        Text('1kHz', style: TextStyle(color: AppColors.textLight, fontSize: 11)),
        Text('저음 ←──── 고음', style: TextStyle(color: AppColors.textLight, fontSize: 11)),
        Text('12kHz', style: TextStyle(color: AppColors.textLight, fontSize: 11)),
      ]),
      const SizedBox(height: 24),

      // 빠른 선택
      Wrap(
        spacing: 8, runSpacing: 8, alignment: WrapAlignment.center,
        children: [2000,4000,6000,8000,10000,12000].map((f) {
          final sel = _selectedFreq == f.toDouble();
          return GestureDetector(
            onTap: () => setState(() {
              _selectedFreq = f.toDouble(); _freqSelected = true; _stopTone();
            }),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: sel ? AppColors.green : Colors.white12,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: sel ? AppColors.green : Colors.white24)),
              child: Text(_freqLabel(f.toDouble()),
                style: TextStyle(
                  color: sel ? Colors.white : AppColors.greenLight,
                  fontSize: 13, fontWeight: sel ? FontWeight.w600 : FontWeight.w400)),
            ),
          );
        }).toList(),
      ),
      const SizedBox(height: 24),

      // 테스트 톤 버튼
      GestureDetector(
        onTap: _toneIsPlaying ? _stopTone : () => _playTone(_selectedFreq),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
          decoration: BoxDecoration(
            color: _toneIsPlaying ? Colors.white12 : AppColors.green,
            borderRadius: BorderRadius.circular(30)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(_toneIsPlaying ? Icons.stop : Icons.volume_up,
              color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Text(_toneIsPlaying ? '정지 (3초 재생 중)' : '이 소리 들어보기',
              style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
      const SizedBox(height: 8),
      const Text('🎧 이어폰 착용 · 볼륨 낮게',
        style: TextStyle(color: AppColors.textLight, fontSize: 11)),

      const Spacer(),
      _NextBtn(
        label: _freqSelected ? '${_freqLabel(_selectedFreq)} 로 설정하기' : '주파수를 선택해 주세요',
        onTap: _next,
        enabled: true,
      ),
    ]),
  );

  // 페이지 2: 매일 루틴 안내
  Widget _buildPage2() => Padding(
    padding: const EdgeInsets.all(32),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('매일 이렇게 사용하세요', style: TextStyle(
        color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
      const SizedBox(height: 32),
      _RoutineCard(
        step: '01', icon: '🧠',
        title: '신경 디싱크 (핵심)',
        desc: '아무때나 · 하루 1시간\n소리를 들으면 자동으로 기록됩니다',
        color: AppColors.green),
      const SizedBox(height: 12),
      _RoutineCard(
        step: '02', icon: '😴',
        title: '수면 모드 (잠들기 전)',
        desc: '잠들기 어려울 때\n브라운노이즈 + 타이머로 편안하게',
        color: AppColors.gold),
      const SizedBox(height: 12),
      _RoutineCard(
        step: '03', icon: '📊',
        title: '오늘 기록 (선택)',
        desc: '이명 강도 · 수면 · 스트레스\n기록이 쌓이면 패턴을 발견해요',
        color: AppColors.textSecond),
      const SizedBox(height: 48),
      const Text('30분 이상 → 부분완료 🔶\n60분 이상 → 완료 ✅\n자동으로 달력에 표시됩니다',
        textAlign: TextAlign.center,
        style: TextStyle(color: AppColors.greenLight, fontSize: 14, height: 1.7)),
      const SizedBox(height: 48),
      _NextBtn(label: '다음', onTap: _next),
    ]),
  );

  // 페이지 3: 준비 완료
  Widget _buildPage3() => Padding(
    padding: const EdgeInsets.all(32),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('🎉', style: TextStyle(fontSize: 64)),
      const SizedBox(height: 24),
      const Text('준비 완료!', style: TextStyle(
        color: Colors.white, fontSize: 32, fontWeight: FontWeight.w700)),
      const SizedBox(height: 16),
      const Text('6주 프로그램을 시작합니다\n매일 조금씩, 꾸준히가 가장 중요합니다',
        textAlign: TextAlign.center,
        style: TextStyle(color: AppColors.greenLight, fontSize: 16, height: 1.6)),
      const SizedBox(height: 40),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16)),
        child: Column(children: [
          const Text('내 이명 주파수', style: TextStyle(color: AppColors.greenLight, fontSize: 13)),
          const SizedBox(height: 8),
          Text(_freqLabel(_selectedFreq), style: const TextStyle(
            color: Colors.white, fontSize: 36, fontWeight: FontWeight.w300)),
          Text(_freqDesc(_selectedFreq), style: const TextStyle(
            color: AppColors.greenLight, fontSize: 13)),
          const SizedBox(height: 16),
          const Text('언제든지 치료 탭에서 변경 가능합니다',
            style: TextStyle(color: AppColors.textLight, fontSize: 11)),
        ]),
      ),
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.orange.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.orange.withOpacity(0.4))),
        child: const Text(
          '⚠️ 통증·어지러움·이명 악화 시 즉시 중단\n이 앱은 의료기기가 아닙니다',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.orange, fontSize: 12, height: 1.5)),
      ),
      const SizedBox(height: 40),
      _NextBtn(label: '지금 바로 시작하기 →', onTap: _finish),
    ]),
  );
}

class _InfoRow extends StatelessWidget {
  final String icon, text;
  const _InfoRow({required this.icon, required this.text});
  @override
  Widget build(BuildContext context) => Row(children: [
    Text(icon, style: const TextStyle(fontSize: 18)),
    const SizedBox(width: 12),
    Expanded(child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 14))),
  ]);
}

class _RoutineCard extends StatelessWidget {
  final String step, icon, title, desc;
  final Color color;
  const _RoutineCard({required this.step, required this.icon,
    required this.title, required this.desc, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.08),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: color.withOpacity(0.4))),
    child: Row(children: [
      Column(children: [
        Text(icon, style: const TextStyle(fontSize: 28)),
        const SizedBox(height: 4),
        Text(step, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600)),
      ]),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Text(desc, style: const TextStyle(color: AppColors.greenLight, fontSize: 12, height: 1.5)),
      ])),
    ]),
  );
}

class _NextBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool enabled;
  const _NextBtn({required this.label, required this.onTap, this.enabled = true});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity,
    child: ElevatedButton(
      onPressed: enabled ? onTap : null,
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.green,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
      child: Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
    ),
  );
}

class _BytesSource extends StreamAudioSource {
  final List<int> _bytes;
  _BytesSource(this._bytes);
  @override
  Future<StreamAudioResponse> request([int? start, int? end]) async {
    start ??= 0; end ??= _bytes.length;
    return StreamAudioResponse(
      sourceLength: _bytes.length, contentLength: end-start,
      offset: start, contentType: 'audio/wav',
      stream: Stream.value(_bytes.sublist(start, end)));
  }
}
