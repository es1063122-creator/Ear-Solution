import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../home/main_shell.dart';
import '../sound/desync_screen.dart';
import '../sound/haptic_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppColors.cream,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 헤더
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Auris', style: Theme.of(context).textTheme.headlineMedium),
                    Text('오늘도 편안한 하루 되세요', style: Theme.of(context).textTheme.bodySmall),
                  ]),
                  const CircleAvatar(
                    backgroundColor: AppColors.greenLight,
                    child: Icon(Icons.person_outline, color: AppColors.green),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // 오늘 상태 카드
              _TodayStatusCard(),
              const SizedBox(height: 12),

              // 지금 소리 켜기
              _QuickSoundButton(onTap: () => ref.read(currentTabProvider.notifier).state = 1),
              const SizedBox(height: 12),

              // 신경 디싱크 카드
              _DesyncProgramCard(onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const DesyncScreen()));
              }),
              const SizedBox(height: 12),

              // 햅틱 바이모달 카드
              _HapticCard(onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const HapticScreen()));
              }),
              const SizedBox(height: 16),

              // 빠른 이완
              Text('빠른 이완', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: _QuickRelaxCard(
                  icon: Icons.air,
                  label: '4-7-8 호흡',
                  onTap: () => _showBreathing(context),
                )),
                const SizedBox(width: 10),
                Expanded(child: _QuickRelaxCard(
                  icon: Icons.self_improvement,
                  label: '근육 이완',
                  onTap: () {},
                )),
              ]),
              const SizedBox(height: 16),

              // 이번 주 요약
              _WeeklySummaryCard(),
            ],
          ),
        ),
      ),
    );
  }

  void _showBreathing(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.cream,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => const _BreathingGuide(),
    );
  }
}

class _TodayStatusCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: AppColors.greenDark, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('오늘 이명 강도', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.greenLight)),
        const SizedBox(height: 4),
        Text('기록 전', style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: Colors.white)),
        const SizedBox(height: 6),
        const Text('오늘 기록을 남겨보세요', style: TextStyle(color: AppColors.greenLight, fontSize: 12)),
      ])),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: AppColors.green, borderRadius: BorderRadius.circular(12)),
        child: const Icon(Icons.edit_note, color: Colors.white, size: 28),
      ),
    ]),
  );
}

class _QuickSoundButton extends StatelessWidget {
  final VoidCallback onTap;
  const _QuickSoundButton({required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(color: AppColors.green, borderRadius: BorderRadius.circular(16)),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.graphic_eq, color: Colors.white),
        const SizedBox(width: 8),
        Text('지금 소리 켜기', style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.white)),
      ]),
    ),
  );
}

class _DesyncProgramCard extends StatelessWidget {
  final VoidCallback onTap;
  const _DesyncProgramCard({required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1E3932), Color(0xFF00704A)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: AppColors.gold, borderRadius: BorderRadius.circular(20)),
            child: const Text('뉴캐슬대학 2025 연구', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600)),
          ),
          const Icon(Icons.chevron_right, color: AppColors.greenLight, size: 20),
        ]),
        const SizedBox(height: 10),
        const Text('신경 디싱크 세션', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        const Text('이명을 일으키는 뇌 신경 동기화를 깨뜨려요\n하루 1시간 · 6주 프로그램',
          style: TextStyle(color: AppColors.greenLight, fontSize: 12, height: 1.5)),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: const LinearProgressIndicator(
            value: 0, backgroundColor: Colors.white24, color: AppColors.gold, minHeight: 4),
        ),
        const SizedBox(height: 6),
        const Text('0 / 42일 완료', style: TextStyle(color: AppColors.greenLight, fontSize: 11)),
      ]),
    ),
  );
}

class _HapticCard extends StatelessWidget {
  final VoidCallback onTap;
  const _HapticCard({required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.greenLight),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: AppColors.greenLight, borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.vibration, color: AppColors.green, size: 24),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('햅틱 바이모달 세션',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.greenDark)),
          const SizedBox(height: 2),
          Text('소리 + 진동 동시 자극 · 15분 · FDA 동일 원리',
            style: Theme.of(context).textTheme.bodySmall),
        ])),
        const Icon(Icons.chevron_right, color: AppColors.textLight),
      ]),
    ),
  );
}

class _QuickRelaxCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QuickRelaxCard({required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.white, borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.greenLight),
      ),
      child: Column(children: [
        Icon(icon, color: AppColors.green, size: 26),
        const SizedBox(height: 6),
        Text(label, style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w500)),
      ]),
    ),
  );
}

class _WeeklySummaryCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: AppColors.white, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppColors.greenLight),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('이번 주 요약', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 10),
      Text('기록이 쌓이면 패턴 분석을 시작할 수 있어요',
        style: Theme.of(context).textTheme.bodySmall),
    ]),
  );
}

// 4-7-8 호흡 가이드
class _BreathingGuide extends StatefulWidget {
  const _BreathingGuide();
  @override
  State<_BreathingGuide> createState() => _BreathingGuideState();
}

class _BreathingGuideState extends State<_BreathingGuide> {
  final List<Map<String, dynamic>> _steps = [
    {'label': '들이쉬기', 'duration': 4, 'color': AppColors.green, 'icon': Icons.arrow_downward},
    {'label': '참기', 'duration': 7, 'color': AppColors.gold, 'icon': Icons.pause},
    {'label': '내쉬기', 'duration': 8, 'color': AppColors.greenDark, 'icon': Icons.arrow_upward},
  ];
  int _step = 0;
  int _count = 0;
  int _round = 0;
  bool _running = false;
  Timer? _stepTimer;

  void _start() {
    setState(() { _running = true; _step = 0; _count = 0; _round = 0; });
    _tick();
  }

  void _tick() {
    final duration = _steps[_step]['duration'] as int;
    _stepTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _count++);
      if (_count >= duration) {
        t.cancel();
        if (_step == 2) {
          setState(() { _round++; _step = 0; _count = 0; });
          if (_round < 3) _tick();
          else setState(() => _running = false);
        } else {
          setState(() { _step++; _count = 0; });
          _tick();
        }
      }
    });
  }

  @override
  void dispose() { _stepTimer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final step = _steps[_step];
    final duration = step['duration'] as int;
    final progress = _running ? _count / duration : 0.0;

    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('4-7-8 호흡법', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 4),
        Text('3회 반복 · 스트레스 및 이명 완화', style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 24),

        if (_running) ...[
          Container(
            width: 120, height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: step['color'] as Color, width: 3),
              color: (step['color'] as Color).withOpacity(0.1),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(step['icon'] as IconData, color: step['color'] as Color, size: 32),
              const SizedBox(height: 4),
              Text(step['label'] as String,
                style: TextStyle(color: step['color'] as Color, fontWeight: FontWeight.w600)),
              Text('${duration - _count}초',
                style: TextStyle(color: step['color'] as Color, fontSize: 13)),
            ]),
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: AppColors.cream2,
              color: step['color'] as Color,
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 8),
          Text('${_round + 1} / 3 라운드', style: Theme.of(context).textTheme.bodySmall),
        ] else ...[
          Text(_round >= 3 ? '완료! 수고하셨어요 🎉' : '준비되면 시작하세요',
            style: Theme.of(context).textTheme.bodyMedium),
        ],

        const SizedBox(height: 20),
        if (!_running || _round >= 3)
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _round >= 3 ? () => Navigator.pop(context) : _start,
              child: Text(_round >= 3 ? '닫기' : '시작'),
            ),
          ),
      ]),
    );
  }
}
